#   Copyright (c) 2010, Diaspora Inc.  This file is
#   licensed under the Affero General Public License version 3 or later.  See
#   the COPYRIGHT file.

Autotest.add_discovery { "rails" }
Autotest.add_discovery { "rspec2" }
