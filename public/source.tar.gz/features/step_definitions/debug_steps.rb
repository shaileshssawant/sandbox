When 'I debug' do
  debugger
  true
end
