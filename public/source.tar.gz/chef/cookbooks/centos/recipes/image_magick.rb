execute "install ImageMagick" do
  command "yum install -y ImageMagick"
end
